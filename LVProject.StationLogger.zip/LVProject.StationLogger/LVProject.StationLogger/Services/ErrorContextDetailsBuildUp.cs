﻿using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils;
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;

namespace LVProject.StationLogger.Services
{

    public static class ErrorContextDetailsBuildUp
    {
        /// <summary>
        /// Équivalent du sous-VI ErrorContextDetailsBuildUp.vi
        /// Construit le contexte d'erreur complet et l'ajoute au document XML.
        /// (Version optimisée : retourne uniquement l'ErrorCluster)
        /// </summary>
        public static ErrorCluster Execute(
            object sequenceContextIn,
            XmlDocument? docRefIn,
            XmlNode? parentRefIn,
            ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return errorIn;
            }

            try
            {
                var stepIndex = GetPropertyXML.Execute(sequenceContextIn, "RunState.Caller.RunState.StepIndex", errorIn);
                var numSteps = GetPropertyXML.Execute(sequenceContextIn, "RunState.Caller.RunState.NumStepsExecuted", stepIndex.ErrorOut);
                var callStackDepth = GetPropertyXML.Execute(sequenceContextIn, "RunState.Caller.RunState.CallStackDepth", numSteps.ErrorOut);

                var stackChain = GetCallStackChain.Execute(sequenceContextIn, callStackDepth.ErrorOut);

                string callStackTemplate = "<Prop Name='CallStackChain' Type='String' Flags='0x0'>\r\n<Value>%s%</Value>\r\n</Prop>";
                string callStackXml = callStackTemplate.Replace("%s%", stackChain.RawString);

                string concatenatedXml = stepIndex.XmlString + numSteps.XmlString + callStackDepth.XmlString + callStackXml;

                ErrorCluster finalError = AddNodeWithStringValue.Execute(
                    docRefIn,
                    parentRefIn,
                    "ErrorContext",
                    concatenatedXml,
                    stackChain.ErrorOut);

                return finalError;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Exception dans ErrorContextDetailsBuildUp : {ex.Message}";
                Logger.WriteError("ErrorContextDetailsBuildUp", sourceMsg, ex);

                return new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }
        }
    }


    public static class GetPropertyXML
    {
        /// <summary>
        /// Équivalent du sous-VI GetPropertyXML.vi fusionné avec le sous-VI de l'API TestStand.
        /// Extrait une propriété du contexte TestStand et la convertit en chaîne XML.
        /// </summary>
        public static (string XmlString, ErrorCluster ErrorOut) Execute(object sequenceContextIn, string lookupString, ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return (string.Empty, errorIn);
            }

            try
            {

                dynamic context = sequenceContextIn;
                dynamic targetProperty = context.AsPropertyObject.GetPropertyObject(lookupString, 0);

                string xmlData = targetProperty.GetXML(4, 1, "", "");

                return (xmlData, errorIn);
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de l'extraction XML de la propriété '{lookupString}' : {ex.Message}";
                Logger.WriteError("GetPropertyXML", sourceMsg, ex);

                var errorOut = new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };

                return (string.Empty, errorOut);
            }
        }
    }


    public static class GetCallStackChain
    {
        /// <summary>
        /// Équivalent du sous-VI GetCallStackChain.vi.
        /// Remonte l'historique des appels TestStand grâce à une boucle While.
        /// </summary>
        public static (string RawString, ErrorCluster ErrorOut) Execute(object sequenceContextIn, ErrorCluster errorIn)
        {
            
            if (errorIn.Status)
            {
                return (string.Empty, errorIn);
            }

            dynamic? currentContext = sequenceContextIn;
            bool isRootContext = true; // Empêche de détruire le contexte d'origine fourni par le VI Global

            
            StringBuilder callStackBuilder = new StringBuilder();

            try
            {
                while (true) 
                {
                    
                    string callStackName = currentContext.CallStackName;
                    int callStackDepth = currentContext.CallStackDepth;

                    
                    if (callStackDepth > 0)
                    {
                        
                        callStackBuilder.Append(callStackName).Append(" | ");
              
                        dynamic nextContext = currentContext.Caller;

                        if (!isRootContext && currentContext != null && Marshal.IsComObject(currentContext))
                        {
                            Marshal.ReleaseComObject(currentContext);
                        }

                        currentContext = nextContext;
                        isRootContext = false;

                    }
                    else
                    {
             
                        callStackBuilder.Append(callStackName);

                        break;
                    }
                }

                return (callStackBuilder.ToString(), errorIn);
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de la récupération du Call Stack : {ex.Message}";
                Logger.WriteError("GetCallStackChain", sourceMsg, ex);

                return (string.Empty, new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                });
            }
            finally
            {
                // Sécurité : Nettoyage du tout dernier contexte parent s'il est encore en mémoire
                if (!isRootContext && currentContext != null && Marshal.IsComObject(currentContext))
                {
                    Marshal.ReleaseComObject(currentContext);
                }
            }
        }
    }
}