﻿using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils;
using System;
using System.Text.RegularExpressions;
using System.Xml;

namespace LVProject.StationLogger.Services
{

    //  ADD DATA TO XML DOC
    public static class AddDataToXmlDoc
    {
        /// <summary>
        /// Équivalent du sous-VI AddDataToXmlDoc.vi
        /// Boucle sur le contexte TestStand pour extraire et écrire toutes les variables globales et locales.
        /// (Version optimisée : retourne uniquement l'ErrorCluster)
        /// </summary>
        public static ErrorCluster Execute(
            object sequenceContextIn,
            XmlDocument? docRefIn,
            XmlNode? parentRefIn,
            ErrorCluster errorIn)
        {
            if (errorIn.Status) return errorIn;

            try
            {
                dynamic currentContext = sequenceContextIn;
                ErrorCluster currentError = errorIn;
                int iteration = 0;

                while (true)
                {
                    string callerName = "Caller" + iteration.ToString();


                    var (callerNodeRef, addNodeErr) = AddNode.Execute(docRefIn, parentRefIn, callerName, currentError);
                    currentError = addNodeErr;

                    currentError = AddSequenceFileName.Execute(currentContext, docRefIn, callerNodeRef, currentError);

                    var prop1 = GetPropertyXML.Execute(currentContext, "RunState.Caller.StationGlobals", currentError);
                    currentError = AddNodeWithStringValue.Execute(docRefIn, callerNodeRef, "StationGlobals", prop1.Item1, prop1.Item2);

                    var prop2 = GetPropertyXML.Execute(currentContext, "RunState.Caller.FileGlobals", currentError);
                    currentError = AddNodeWithStringValue.Execute(docRefIn, callerNodeRef, "FileGlobals", prop2.Item1, prop2.Item2);

                    var prop3 = GetPropertyXML.Execute(currentContext, "RunState.Caller.Parameters", currentError);
                    currentError = AddNodeWithStringValue.Execute(docRefIn, callerNodeRef, "Parameters", prop3.Item1, prop3.Item2);

                    var prop4 = GetPropertyXML.Execute(currentContext, "RunState.Caller.Locals", currentError);
                    currentError = AddNodeWithStringValue.Execute(docRefIn, callerNodeRef, "Locals", prop4.Item1, prop4.Item2);

                    var prop5 = GetPropertyXML.Execute(currentContext, "RunState.Caller.RunState.Step", currentError);
                    currentError = AddNodeWithStringValue.Execute(docRefIn, callerNodeRef, "Step", prop5.Item1, prop5.Item2);

                    int callStackDepth = currentContext.CallStackDepth;
                    bool stopConditionFromDepth;

                    if (callStackDepth == 1)
                    {

                        stopConditionFromDepth = true; 
                    }
                    else
                    {

                        currentContext = currentContext.Caller;
                        stopConditionFromDepth = false; 
                    }

                    if (stopConditionFromDepth || currentError.Status)
                    {

                        break;
                    }

                    iteration++;
                }

 
                return currentError;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Exception globale dans AddDataToXmlDoc : {ex.Message}";
                Logger.WriteError("AddDataToXmlDoc", sourceMsg, ex);

                return new ErrorCluster { Status = true, Code = -1, Source = sourceMsg };
            }
        }
    }


    //  CLASSE UTILITAIRE : ADD NODE
    public static class AddNode
    {
        /// <summary>
        /// Équivalent du sous-VI AddNode.vi
        /// Crée un nouveau nœud XML et l'attache à un parent.
        /// (Version optimisée : retourne un Tuple C# avec le nouveau nœud et l'erreur)
        /// </summary>
        public static (XmlNode? NewNodeRefOut, ErrorCluster ErrorOut) Execute(XmlDocument? docRefIn, XmlNode? parentRefIn, string nodeName, ErrorCluster errorIn)
        {
            if (errorIn.Status) return (null, errorIn);

            try
            {
                if (docRefIn == null || parentRefIn == null)
                {
                    throw new ArgumentNullException("Le document XML ou le nœud parent ne peut pas être null.");
                }

                XmlElement? newElement = docRefIn.CreateElement(nodeName);
                if (newElement == null) throw new Exception("Impossible de créer l'élément XML.");

                XmlNode? appendedNode = parentRefIn.AppendChild(newElement);

                return (appendedNode, errorIn);
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de la création du nœud '{nodeName}' : {ex.Message}";
                Logger.WriteError("AddNode", sourceMsg, ex);

                return (null, new ErrorCluster { Status = true, Code = -1, Source = sourceMsg });
            }
        }
    }


    //  CLASSE UTILITAIRE : ADD SEQUENCE FILE NAME
    public static class AddSequenceFileName
    {
        /// <summary>
        /// Équivalent du sous-VI AddSequenceFileName.vi
        /// Extrait le nom du fichier de séquence via Regex, et les ajoute au XML.
        /// (Version optimisée : retourne uniquement l'ErrorCluster)
        /// </summary>
        public static ErrorCluster Execute(object sequenceContext, XmlDocument? docRefIn, XmlNode? parentRefIn, ErrorCluster errorIn)
        {
            if (errorIn.Status) return errorIn;

            try
            {
                dynamic context = sequenceContext;
                dynamic caller = context.Caller;
                string callStackName = caller.CallStackName;

                string pattern = @"(?<=\().*?(?=\))";
                Match match = Regex.Match(callStackName, pattern);

                string sequenceFileName = string.Empty;
                string callerSequence = string.Empty;

                if (match.Success)
                {
                    sequenceFileName = match.Value;
                    callerSequence = callStackName.Substring(0, match.Index);
                }
                else
                {
                    callerSequence = callStackName;
                }

                callerSequence = callerSequence.Replace("(", "");

                ErrorCluster err1 = AddNodeWithStringValue.Execute(docRefIn, parentRefIn, "CallerSequenceFile", sequenceFileName, errorIn);

                ErrorCluster err2 = AddNodeWithStringValue.Execute(docRefIn, parentRefIn, "CallerSequence", callerSequence, err1);

                return err2;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de l'extraction du nom de séquence : {ex.Message}";
                Logger.WriteError("AddSequenceFileName", sourceMsg, ex);

                return new ErrorCluster { Status = true, Code = -1, Source = sourceMsg };
            }
        }
    }
}