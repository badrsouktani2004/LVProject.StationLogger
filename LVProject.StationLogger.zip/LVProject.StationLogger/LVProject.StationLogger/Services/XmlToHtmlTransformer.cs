﻿using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils;
using System;
using System.IO;
using System.Xml;
using System.Xml.Xsl;

namespace LVProject.StationLogger.Services
{
    public static class XmlToHtmlTransformer
    {
        public static ErrorCluster Execute(
            string xsltStyleSheetCode,
            string xmlInput,
            string htmlFilePath,
            ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return errorIn;
            }

            // Déclaration des variables à l'extérieur pour pouvoir les fermer à la fin
            StringReader? xsltStringReader = null;
            XmlReader? xsltXmlReader = null;
            XslCompiledTransform? transformEngine = null;

            StringReader? xmlStringReader = null;
            XmlReader? xmlInputReader = null;
            XmlWriter? htmlWriter = null;

            try
            {
                // 1. Voie Supérieure (Style XSLT)
                xsltStringReader = new StringReader(xsltStyleSheetCode);
                xsltXmlReader = XmlReader.Create(xsltStringReader);

                transformEngine = new XslCompiledTransform();
                transformEngine.Load(xsltXmlReader);

                // 2. Voie Inférieure (Données XML)
                xmlStringReader = new StringReader(xmlInput);
                xmlInputReader = XmlReader.Create(xmlStringReader);

                // 3. Préparation du Fichier de Sortie
                htmlWriter = XmlWriter.Create(htmlFilePath);

                // 4. Transformation Centrale
                transformEngine.Transform(xmlInputReader, htmlWriter);

                return errorIn;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de la transformation XML vers HTML : {ex.Message}";
                Logger.WriteError("XmlToHtmlTransformer", sourceMsg, ex);

                return new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }
            finally
            {
                // =====================================================================
                // 5. L'ESCALIER DES "CLOSE REFERENCE" (Nettoyage manuel de la mémoire)
                // =====================================================================

                // Fermeture des lecteurs XSLT
                if (xsltXmlReader != null) xsltXmlReader.Close();
                if (xsltStringReader != null) xsltStringReader.Close();

                // Libération du moteur
                transformEngine = null;

                // Fermeture des lecteurs XML
                if (xmlInputReader != null) xmlInputReader.Close();
                if (xmlStringReader != null) xmlStringReader.Close();

                // Fermeture et libération du fichier HTML sur le disque
                if (htmlWriter != null)
                {
                    htmlWriter.Flush(); // S'assure que tout est bien écrit
                    htmlWriter.Close();
                }
            }
        }
    }
}