﻿using System;
using System.Globalization;
using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils; 

namespace LVProject.StationLogger.Services
{
    public static class GetCurrentDateAndTime
    {
        /// <summary>
        /// Équivalent du sous-VI GetCurrentDateAndTime.vi
        /// </summary>
        public static GetCurrentDateAndTimeResult Execute(ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return new GetCurrentDateAndTimeResult
                {
                    ErrorOut = errorIn
                };
            }

            var result = new GetCurrentDateAndTimeResult
            {

                TagName = "DateTimeStamp",
                ErrorOut = errorIn
            };

            try
            {

                DateTime now = DateTime.Now;

                result.Date = now.ToString("dd MMM yyyy", CultureInfo.InvariantCulture);

                result.Time = now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);

                string dateTemplate = "<Prop Name='Date' Type='String' Flags='0x0'>\r\n<Value>%date%</Value>\r\n</Prop>";
                string dateXml = dateTemplate.Replace("%date%", result.Date);

                string timeTemplate = "<Prop Name='Time' Type='String' Flags='0x0'>\r\n<Value>%time%</Value>\r\n</Prop>";
                string timeXml = timeTemplate.Replace("%time%", result.Time);

                result.DateTimeString = dateXml + "\r\n" + timeXml;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Exception lors du formatage du temps : {ex.Message}";

                Logger.WriteError("GetCurrentDateAndTime", sourceMsg, ex);

                result.ErrorOut = new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }

            return result;
        }
    }
}