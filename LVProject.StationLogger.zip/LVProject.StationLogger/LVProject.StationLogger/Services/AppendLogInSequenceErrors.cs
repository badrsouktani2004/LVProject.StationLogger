﻿using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils;
using System;
using System.IO;

namespace LVProject.StationLogger.Services
{
    public static class AppendLogInSequenceErrors
    {
        public static ErrorCluster Execute(
            string logPath,
            DateTime timeStamp,
            string stepName,
            string stepTypeName,
            string errorCode,
            string fileName,
            ErrorCluster errorIn)
        {

            if (errorIn.Status) return errorIn;

            try
            {
                string fullFilePath = Path.Combine(logPath, "SequenceErrors.csv");
                ErrorCluster currentError = errorIn;

                var checkResult = CreateXmlDocument.CheckIfFileExists(logPath, currentError);
                currentError = checkResult.ErrorOut;

 
                if (!checkResult.Exists)
                {
                    Directory.CreateDirectory(logPath);
                }

                bool isFileEmpty;
                if (!File.Exists(fullFilePath))
                {
                    isFileEmpty = true;
                }
                else
                {
                    long fileSize = new FileInfo(fullFilePath).Length;
                    isFileEmpty = (fileSize == 0);
                }

                using (StreamWriter sw = new StreamWriter(fullFilePath, append: true))
                {
                   
                    if (isFileEmpty)
                    {
                        sw.WriteLine("Date;Heure;StepName;StepType;ErrorId;file");

                    }

                    string dateStr = timeStamp.ToString("dd/MM/yyyy");
                    string timeStr = timeStamp.ToString("HH:mm:ss");

                    string csvLine = $"{dateStr};{timeStr};{stepName};{stepTypeName};{errorCode};{fileName}";

                    sw.WriteLine(csvLine);
                }

                return currentError;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de l'écriture dans le fichier CSV : {ex.Message}";
                Logger.WriteError("AppendLogInSequenceErrors", sourceMsg, ex);

                return new ErrorCluster { Status = true, Code = -1, Source = sourceMsg };
            }
        }
    }
}