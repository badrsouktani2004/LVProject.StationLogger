﻿using System;
using System.Xml;
using System.IO;
using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Utils; // AJOUT : Importation de notre Logger

namespace LVProject.StationLogger.Services
{
    public static class CreateXmlDocument
    {
        /// <summary>
        /// Équivalent du sous-VI CreateXmlDocument.vi
        /// </summary>
        public static CreateXmlDocumentResult Execute(string xmlPathIn, ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return new CreateXmlDocumentResult
                {
                    DocRef = null,
                    RootNode = null,
                    FileNamePath = string.Empty,
                    ErrorOut = errorIn
                };
            }

            var result = new CreateXmlDocumentResult
            {
                FileNamePath = xmlPathIn,
                ErrorOut = errorIn
            };

            try
            {

                var initError = NewXmlDocumentStrInit(result.FileNamePath, "StyleSheet.xsl", "Root", errorIn);

                // Si l'initialisation du fichier échoue, on arrête et on renvoie l'erreur
                if (initError.Status)
                {
                    result.ErrorOut = initError;
                    return result;
                }

                result.DocRef = new XmlDocument();
                result.DocRef.Load(result.FileNamePath);
                result.RootNode = result.DocRef.SelectSingleNode("Root");
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Exception dans CreateXmlDocument : {ex.Message}";

                Logger.WriteError("CreateXmlDocument", sourceMsg, ex);

                result.ErrorOut = new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }

            return result;
        }

        /// <summary>
        /// Équivalent du sous-sous-VI NewXmlDocumentStrInit.vi
        /// Crée l'arborescence des dossiers et initialise le fichier texte XML.
        /// </summary>
        public static ErrorCluster NewXmlDocumentStrInit(string path, string styleSheetPath, string rootTag, ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return errorIn;
            }

            try
            {
                string directoryPath = Path.GetDirectoryName(path) ?? string.Empty;

                var checkResult = CheckIfFileExists(directoryPath, errorIn);

                if (checkResult.ErrorOut.Status)
                {
                    return checkResult.ErrorOut;
                }

                if (!checkResult.Exists && !string.IsNullOrWhiteSpace(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                string xmlContent = $"<?xml version=\"1.0\"?>\r\n<?xml-stylesheet type=\"text/xsl\" href=\"{styleSheetPath}\"?>\r\n<{rootTag}/>";

                using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write))
                using (StreamWriter writer = new StreamWriter(fs))
                {
                    fs.SetLength(0);
                    writer.Write(xmlContent);
                }

                return errorIn;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur lors de l'initialisation du fichier XML : {ex.Message}";

                Logger.WriteError("NewXmlDocumentStrInit", sourceMsg, ex);

                return new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }
        }

        /// <summary>
        /// Ton équivalent du sous-VI "Check if file or Folder exists", 
        /// adapté pour utiliser ErrorCluster.
        /// </summary>
        public static (bool Exists, ErrorCluster ErrorOut) CheckIfFileExists(string path, ErrorCluster errorIn)
        {
            if (errorIn.Status)
            {
                return (false, errorIn);
            }

            if (string.IsNullOrWhiteSpace(path))
            {
                return (false, ErrorCluster.NoError);
            }

            try
            {
                bool fileExists = File.Exists(path) || Directory.Exists(path);
                return (fileExists, ErrorCluster.NoError);
            }
            catch (Exception ex)
            {
                string errorMessage = $"ERREUR DE VÉRIFICATION DU FICHIER ! Chemin testé : {path}";

                Logger.WriteError("CheckIfFileExists", errorMessage, ex);

                return (false, new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = $"{errorMessage} - {ex.Message}"
                });
            }
        }
    }
}