﻿using System;
using System.Xml;
using LVProject.StationLogger.DataStructures; // Gardé car ErrorCluster s'y trouve
using LVProject.StationLogger.Utils;

namespace LVProject.StationLogger.Services
{
    public static class AddNodeWithStringValue
    {
        /// <summary>
        /// Équivalent du sous-VI AddNodeWithStringValue.vi
        /// Crée un élément XML, lui assigne une valeur et l'ajoute au parent.
        /// (Version optimisée : retourne uniquement l'ErrorCluster)
        /// </summary>
        public static ErrorCluster Execute(
            XmlDocument? docRefIn,
            XmlNode? parentRefIn,
            string tagName,
            string tagValue,
            ErrorCluster errorIn)
        {

            if (errorIn.Status)
            {
                return errorIn;
            }

            try
            {
  
                if (docRefIn == null || parentRefIn == null)
                {
                    throw new ArgumentNullException("Les références XML d'entrée ne peuvent pas être nulles.");
                }

                
                XmlElement newElement = docRefIn.CreateElement(tagName);
                newElement.InnerXml = tagValue;
                parentRefIn.AppendChild(newElement);

 
                return errorIn;
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Exception dans AddNodeWithStringValue (Tag: {tagName}) : {ex.Message}";
                Logger.WriteError("AddNodeWithStringValue", sourceMsg, ex);


                return new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }
        }
    }
}