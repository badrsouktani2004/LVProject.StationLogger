<?xml version="1.0" encoding="utf-8" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="html" encoding="ISO-8859-1" doctype-public="-//W3C//DTD HTML 4.01//EN" doctype-system="http://www.w3.org/TR/html4/strict.dtd" indent="yes"/>
	<xsl:template match="/">
		<html>
			<style>
				* {
				font-size: 100%;
				font-family: Arial;
				}
				.collapse {
				border-collapse: collapse;
				}
				.separate {
				border-collapse: separate;
				}
				table {
				margin-top:1em;
				margin-bottom:1em;
				border-width: 0.15em;
				border-style: solid;
				border-color:#000000;
				}
				table th, table td {
				padding: 5px 10px 5px 5px;
				border: solid 0.15em;
				border-color:#000000;
				}
				tr { page-break-inside:avoid; page-break-after:auto }
				.quiz-chartTip {
				padding: 5px 10px;
				border: 1px solid rgba(0,0,0,.15);
				border-radius: 4px;
				background-color: rgba(255,255,255,.9);
				position: absolute;
				z-index: 50;
				max-width: 250px;
				}

				.quiz-graph {
				padding: 10px;
				height: 370px;
				width: 100%;
				}

				.quiz-graph .x-labels {
				text-anchor: middle;
				}

				.quiz-graph .y-labels {
				text-anchor: end;
				}

				.quiz-graph .quiz-graph-grid {
				stroke: #ccc;
				stroke-dasharray: 0;
				stroke-width: 1;
				}

				.label-title {
				text-anchor: middle;
				font-size: 12px;
				fill: gray;
				}

				.quiz-graph-dot, .quiz-graph-start-dot{
				fill: #4465AD;
				stroke-width: 2;
				stroke: white;
				}

				.quiz-graph-polyline, .quiz-graph-start-polyline{
				fill: none;
				stroke: #4465AD;
				stroke-width: 2;
				}
				.brand-logo{ margin-top:30px;margin-left:10px }
				.section{ margin-top:10px;margin-left:10px;margin-right:10px;margin-bottom:10px }


				@media print{
				body{ margin:0px;}
				.brand-logo{ margin-top:10px;margin-left:0px }
				.section{ margin-left:0px;margin-right:0px }
				}
				ul { list-style-type: square; }
				li { margin: 5px 0; }
				.attr { color: blue; list-style-type: none; }
				.value { color: red; }
				.node { font-weight: bold; }
				.tree-node {
				margin-left: 20px;
				}
				.children {
				display: none;
				margin-left: 20px;
				}
				.toggle {
				cursor: pointer;
				color: blue;
				text-decoration: underline;
				}
			</style>
			<body>
				<!-- Head -->
				<head>
					<title>
						<xsl:text>Error</xsl:text>
					</title>
				</head>
				<!-- Logo -->
				<div class="brand-logo">
					<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA6QAAADdCAYAAACser9JAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAJv9JREFUeNrs3c9x28iiL2D4lvdH5yYw9PotjiYC0xFYjsBUAldSuWYtaT3lsnwTEB2B6QhMRzCaxVsPJ4F3dSK4D221bFmWCJDsBhrk91Wx7BnJYLMBAvih/z2pAAAA7vjtzZtR/cfd163nS/7Zon79Hf9+Xb+uwp+/v317pUZ5zBNVwCMnn5wW9YlpobZhUN/bIXMzBGnPOXv1H/tq4nH1OWc+sH06rv8Ir3/F60mO/buIry/1K9TPVV1P144WntYH4P+qhs5OTkN4APCxg4vMrH692vKLdTipf874Fi+GdrGzH7OeEyb169Qee1T4rrxQDb5/JDsf7ds3jZ4U/v0K+/CgumntHHf0tqP4Gt9es+pyXMVz9IfSHhw6B3UYSFUBd754o6qbJ54H4emqp2IbeR1P4OQl5AGwTfd5RzGIjgop1n58HdflW1Q3jRbv9aTbLf+hCrjjqMP3OlDdG5nECwt5L9xjNQHAwK9n4Z4htPT9FYJfVe4Qj1Es31+hvPXLveKO0EJKXyExhN+pKt+4Dk9UQzZaRwEYdBCN17LRAIs/Dq/Yanr++9u37hm3mBZSbk9a+x2fsPa18G1sEieWIP33IdTrRE0AMMQgWr9Ca+hlNfwJ70L5L2OL6dje3U5aSLl11MN7hhbZC1W/thCaQteWM1WR3LEqAGBgQTQ0LryrtnO4SfhMocV0Wv95Yh6S7aKFlLvhcBdC8LZ5rQocmwDsfBg9q//4o9r+uQ8m1c0Y07G9LpCyXSexEEb76Po5ik/z2KwOJ6oh6fdh0tP3AQBWvWbtxQmLdmneg3CNDl143zkCBFK2x8se31sL3+a05qVlMiMAhhBGw0P9MFZ0vKNVcBzHlnqILJAy8JNZ35O3mNJ7c/u6riT7PoR6HKkJAAZwvQoto7sexr7Wg1AqkDJsfQfCkXWmktBKmobWUQBKD6MTYfQH+zGUjlSFQMowvVSGrXDgRLzxBT7U31hNAFDwtSqEr0s18WAo/ailVCBlmDfgJbROaiFNQ+ue+gNgu8PoZzWxNJTqviuQMjClBME9M8UmMXESXvsi3/dYagBouk59rHTTbRNKtSALpAxISTPc6rabxrEqUG8AbJ0QskaqoZWDuC4rAikli911S1oD9EDrXhImN1JvAGzXPVt4aGp402pOrXUvkOIGfK1QardsTPfn1S/0ob48DAGgxGvUqCpnjoOr+jV/5FUiXXcH4mlBB1G4IczxJGMRX5Qf/kJInto1GztVjyvXFw8Lx9HfW/A5XAOG6XoH7lGu4ufkRtjfX1TDT9eoPh6aXt3ZH1e/v33beB6NPd324+t5dTNzfZ8PfMM67Wd12c+24Bw0qvJ02S7iHPSklG/bnQV+Uzvf4EDcSrELwx+FFu9Zm5PeAOo41/Hc1ou6HueO9rL3U72PniT6HGeZgrXjCPKeKwb5HXPPtrXXqBBM3tevaap7sbjWfJizpK+GkOt4b3k98GNhq6/zuuzuppLHy+m2m4ZWP/UEgGtU29B2HoPbWcqGgXpbs/r1Kmy76qf3VmihNXFh4QTS3VRy6DO5TBrjOO6ER8SeAmM1AcAOX6Pm9evXGESztSKGkFu/Duu/vqi6H0ZxZOJMgZSyTnAhjJb8pRyZFS0ZrX8NFyhVAMAOX6NCF+kXXQ6Vit1Df626bS211rhASmGGsN7na7spiYlW0ofFenFxAqDEa1QIULl7sx32NV43tMTG1tLzLQv4CKS0PMEN4SZcUFCX6gWAXZW7N9tJHQinfX/IGIgPO3o7PfAEUgo6wQ3BXuxazOaMm7gn1ocnpQCU6nnGbc/rIHhRygeNwbir8uiBJ5BSgJfKunO66PYzNKWPowbAdSqHMGnRYWkftg6lJ1U3632OHVoCKT2KY+ZynOAWVZ4FdQ+07CVjciP1AcAw7tdCt9Jc9z/vC17r/TDT/eRd++4tBVL6letp24f6NcuwXS176Yx0gf52oQ/1MFITABRqnHHb01I/dAzK7wdevwikNMjVbz6c3D5l2rZuu+kYM6keACjfL5m2Oy+4dfRWGEuavZXUISaQ0oPYXTfHF/AqLnQcWkhznOR0201nXNfleMe/B10tMg4ApQWmT6V/8LAcTJW/Ffe5Q0wgpR+5WoU+3Pn7LNN7TOy+ZF77HgBA0UaZtns1kM//aaD1i0BKg1zjB2ePhFMhqkyT2Fq+c+LnnjgEANjFQPr727fzIXz4DsopkAqk9HAjPs705ZvdHYtQ/z08eVtkeJ/9XQ1RmexqK6EwCgDDkDWUxiE8CKR0KFcL40NdKnTbHUAw27VxufHz6q4LQOnXq1GmTV8NrCoWmbdvfpLCPFUFW6+L7rq3wnTdx5lC9ZldmewkHAL+xY59B1x8AChdrkB6PaRK+P3t27Am6aHDYXdoId1icc3FHDfiszgT2v0TyKLK8xRupHtFUrvWWnhqlwMACKR0L1d33Q9r/qzEz7KLQsCf7MIHjQ9lRnY5ADtsrAoQSOnjRjy0jObornsd1x19jHGkw7ArAd/YUQCGYqEKEEjZJl2OHf0mY7fdvdjaRRrjOAPz1ordvMd2NQBDcHf1ggzXRNdDBFI61+Xsuve9z/TeL+3WpI58PgDYCe6hEEjpTpw2fJxh04uG7rq3cnXbPdi1JUsyO9jWNV7j55rYxQBwc81XBQikbMNJp1XQjDPw5gile5UTamrbOgOt1lEAhmieabs7M6EhAill6GN23fs+ZSrDrnc5mSbe3ta1OsfPMym83gHgITnXDD3V0wyBlC5uxsNELjnW7AzddVeZrEi33XwPBVJerEJdHm9ZHU2qtOvvzuvX384uAHTgz4zbHtWvd6oYgZTcSmgdve22O80YOHbZ+4EcM31J3V333GkFgI7MM29/8tubN0IpAilZ5RpjuU64zNVt9/WO7+OLxNvbmnEl8XOMEm4y9AyYVwDQjasO3uO4vl5eqmoEUnLcjI8T34x/OzmuszZWnJE3x1iI/W2dHbZlveZofd6WSYBSP6zQOgpA19f4LkJpaCm9NKYUgZTSb8Zvfdjg3+YaSzrZ8X2dOijtD33R7Fj+lJ/hur4xmFYA0K0PHb1PuJf6HOcfAYGUJHpd7uURuu1mEFusU4f9oS8Bk/qYeF8BQPdmHb5XCKN/1KH0TGspAikbqU8iIYzmOJHM1umueyc4hZPqIkO5Rp7oJQ9M46F2hY7lniTe7EUFAB2L913zjt82PJT+SzBFIGUTuVoMU7Rw5nrSd7TLOzxOtpN6nMlQW0lTHwvTOI4HAPrQRy+dvTvB9N0uz9eBQMqK4pOsErvr3so1FuLA3k9+wZoM7cloLO8k8WZNZgRAbzL2MGsbTI9jMA3deSdaTRFI6SuYzVK0EtXbuMp0Ut2LXZV3+YI1zVC3xwOrhkmVtrv6Rt3UASCRwwLKEIZHhSVi/qe+5/oonJLDU1WwFUqcXfenm/xMQedl1e3g/xKF/ZSyq23o/no2oM+furuuyYx4VFzr9rWaWElYOuxENcBqwtCc+pwT7nFKefh+EF9huZh5dTOsy0NcBFI3R1/7948zbPo6dhdJeZOfI5CGJ3UnOz7e7yKGslRPLEPL82QIS57EcDBKfOM8d2ZhiVznXICHHMZzTmmtkuP4CmNNQyAN94xfEt87IpAyECWPHf0mPD2rT1ih6+5+pjqY7uoBEMJ4fII6SbjZ04HUqaVeMtfv0Nanrb8PZ3YbDNbzMMvrwMo8z/kgM17jX9V//VxwHYyqm0aH47qsX+ukumk9ncdhWyCQbvsNY6bt5lg/9EOmQPpylwNpdJ44kIZldQ5KftIZg1LKsLQYQqtwxyYDLLNACsOV+rzeWSjNufHYdTe0lF4ObT/G1tO7AdUM9vzEpEYDFtfhzBHwFpmCSK5wc7DrU5PH8Rupw1Tpy+qkfhjzoQKAMq/z02qYD9/D/dmkfn2svk+MdGxJGQTS7ZGrdTRLcIyhKVfXDUvApA9U4/jQozjxQjZJuMnwxPbCIQRAwaH0sBp+j7Bwv/au+r6kjHCKQLoFX+ohBJu7co3R2/lZL+MYlnnizZbaSnqaeHsz3YgAEEo7tS+cIpAOWFx/M8eXdpF5AHqubrv7TmJZHiZMSqvXuP5Z6ocx5w4dAAYUSrftunU3nH6Ms+gjkFK4lwMJNPdPotcZQ+nRrh8UcYzJInUoLexjhpn8Uk5/bw01AIZ2vT+rbpaE2cbePbdrnYYxp5caHARSyv6y5jDtoOyfBlYnQ5O6W/RRbJUshaVeABBKbx5Cv6jyzc/Rt3DvMaluWk0/x96BCKSUIHZjyBEQrjpqKcrVQjoqdRKejoULVMonpjm6yG5y7I8SH/NzhwwAAw2l4Tr2a3XThXeb50IY16/Qlfcv3XkFUsowyO66d06e11W+lljddvPU72khHy/1/tU6CsA2XPvP6j9+rbZ/XfZRddOd97NGCIGUnmSa0OXWrMOPottuXqmD1qjvJ5L1+4+rtOvuLmJ3JwDYhlC6iBMePduBYBruCcLMvO8KG1aEQLoTsoXRLid2qd8rhN8cXUv2jDH4tuZr6otR30vrpG4d/VABwHYH09CVd7HFHzdMdKi1VCBl4Dfltz718Flytci+dJh8lbqVdBxbKTsXZ9hL+aAhPAy5cIgAsOXB9Kx+hWD6quq2J1yX9mMo1UtOIKWjm/JcT4D6OEnlCsET3TduJjqo/5gn3mxfraSpx7DO4lhbANiFe4Jw3Quh9J/VzXIx2zYzb7jvs36pQEoHcnbX7fzmPGO33Zx1NTSpW0knXa8Hlmnc9LlDA4AdDKbXYf6EODNvaDk9qdI/vO7TpVAqkJJXru66fY6lm2barm6730P/YiDH4WPC+JCULd6djpcGgELvEUKX3ov6FdYyvW05zdlYIJTyoKeqYBjiYO1Rhk1fx9DSlw8xcKR2EFryBI+vQmvgZcLthVbS8w5b1VN3E7bUC5uYq4KVOQ9D+eH0dsm4abzvDD2Tnlc3PZRGA/xIIZRWZtMXSCn7pvxWrwPcwzjH+oSxyHSyCydRE9fc7ON3VbpWxr34EOEsd8HjE86Ux0ZYQFygYJNz1lwoBXbgXDeL9w8ncajOuLrpfTau0vZayh1KF677Ailpw1UOnwr4bLMqTyvpa4H05qlnfUIOrYKniev2rIPip+4erHV0NS9cyIEOhd43Z6qhuPuIRfVj6+l+DKbPq/Ln7AgTHf2qx1zZjCEdgNhtYpRh04ueu+veyjWGdb/rCXgKljqYj3KPz4hLzOwnPt6nDgUA2CigXsWxp6/q15PqZkmZcJ9RYugLrbmX9ppAyuZyTdBTxHpUcXmSXNOPHzl8fhgbMqS6Tb39D44EAEh+jxEmCzyJ652G2XtPqrKWlQnrqB/bUwIpm8nVHaKkG/QPA6u7IUq91Ml+bMVMLrZsp9x3IZAbTwwAecPpbevp3WVlSginp9aoF0hZ/8Z8UuUZPL6ILZOlyNVaO4pjHVwkbsZPzBNvNlcr6Wnq46uPtXYBYJfvO+6E0/AKD4b7uhbfTsiIQMoacnXXLar7YgxLuu3ml7qV9CD1ON34BPOg8M8NALS/zwstp6G1NLSahvVOFz0U40grqUBKGTfmt6YFfmTddvNfEOYZLgKpWzPDE8yUF4yZ2fUAoIj7kOs4wWBoMQ0Pi7tsMQ33FhN7QSCljCB1VegNeq6QvBdnKuZGjlbSlAHSUi8AsP3B9CwG03mHb/1a7Quk9HtjfqvI2UbjGL9cY0mdgL7Xcwj+KZ9IJhuXkWHM9Nw6mgBQ7D1JGGf6oupu4kFLAgqkrHBjHr4suSbjmRX80T9l2u6BcQM/SN1qmOrhSeruv5Z6AYDyg2kYX3rY0dvpNSeQ0vOXpfTxdLMB1ukQpZ7pbi+2bq4tLiEzSlimRWwNBgDKD6XTjkLpc7UtkNJOru66n0r+0LrtDrqeT3v+9/cZOwoAQul9YzUtkNIgrps5yrT52QCqIFc3y7FxAz9IPbnRKLZyrnPMjxJfIELgntrFADDIUJrzfnXP/WBZnqqCIuVqyQs36R/rL+Eu123otnvhELuZSKA+FmZV2q7MoZVzvua/S2kaW4EBgOEJraTjKu1Eh3eFQLpQzQIpy0NTDnuVbgqvBdIfvE98vH1thV5lnHKcbGqS4XMBAAMUHirX9wfhWn6a6S1Cb8S5mi6DLruFietljtRENvuxSzQ3J/xwMr5KvNlVLx7Hid9/WvjEXQBAs5wNCFZeEEhZ4qUqyM7kRj9K3Zo4WXFsRuoJvCz1AgADF4fezDNt/h9qWCDlAbHroqVJ8lPHP57wp1X6cRSTlsd8+L2UTynnsdUXABi+L5m2q7ecQMqSoKQLQX5rzwa7xVK3Kh7FByxNTgv/HABAf+aqQCClW7rrdke33R+FcRopZ6VtbO2PDwVGCd9zEVt7AYDtYMZ8gZSu6K7bOXV9RxynkTrMnW7481WZWRcAtuv+5EotbD/LvpRjogo6FRZFPqhPdDNV8UOgSznj7eixOo6THo0TvleOQA0AnYnzKuTqwfWpvh5b9g6BlKV0Ie2nzgXSKCyVUl8MQ6ibJNzs0SN1nLp1dBpbeQFgqEZV3vXiBVKKpMtuAWJrkdm+unfQcuKdXZJ6UqDx/XVfY51PEr+P7roAsDzsDvEeOdf98cIhIZDyo4kq6C+UqoLv4pIp88Sbvb/O6HHi7YfWURcWAFgSSAf6ED5Xmf92SAik/Eh3XXVfktStpJPYC+CxgFpaeQGgD/PM2x8PsE5ytZAa5iOQcit2RRipid6M74WlnReXTlkk3uxRPN4nVdqnnfPYqgsALDfE5QWfZ9qu2XsFUu7QQtc/3XZ/lnpM5iR2FUo9mZHWUQC2Re6QNMS5M8YCqUBKfhNV4KFAgaZV2u4s4QL4sUrbG2ARW3MBYPDibPE5u5IOas37DL2q7t4/6LIrkBK/aAdVvsHatLefcRa3IV8UU7eSjhNvz8y6AGybeebtnw6oLl4PtI5ZkXVI+5WrL38IE9vaFWGcabuvK9037psWfOG6juUDgG3ypcrbihlm2z37/e3bs5IrITba5Lrn++QwE0ipvq3FmOuEc16faC62tN7+qPLMuBb2xYkj87uwlEpd3yH0TUoMy7rbALCF5h28x1F9fZ/V19EiH8THe+R3A69jVqDLbn9ydtedbXG95ZrEJjwxHDssf/JeuQCgGzEkLjK/Tbj/vCx4gqPLKt8KFB5oC6Tckau77lVo2drieptm3LbJjR6+MM5LOwa2/BgHYLd10bAQepu9K+2D1yE5lClnl2XddQVS4pctZ3fdrV4GIz7VynWitvzLw0prjbTUCwCuu5sLS7JdFnR/fFz/cZzxLcLsujOHl0BKPAFk3PZ0B+ov19OtvTjFOD8+BAgn70UhxZnX5ZnbKwBs8XU3XHO7utZ9DaV9d9+NwTh3i+25o0sg5btcXUNnO9IvPufTrZcOz6JP4lpHAXDdTRxK69fnPpbAC+8ZJ6ycZH6rnD3sEEiHpf7Sjao8s8QGO9EvPobuaabNHxQ8yL/vhwB9P+wIXW2mdgUAO3CvM6+6ncMh3Jv+EZaE6eI+KLxHHC+aa/WE+05MZiSQ8t0kc2jYFTnDt7GkDz8E6HssqZl1AdglffROCuuP/xXCYmxESR1E92P33P+p8o4XvcsD7cJZh7R7ubrr7tQ01mFcY31CC583x1O8o2o3xuKu6iJeqPpwbZ/0Itw4bMPnuC51vT3gB79syxJsKeY7CNvoaT3wvRgWj+v3D+fO0Aiw1hwOd3oGPq9uHviPetgdh75aAinfv5T7Gb+IuziN9SzTSTrchI8sLfLThfG6pwtj8F5Xm16825LPEW6iXtidULxJT9eYHJ4k2s5JlXft+sZ7ovg6jQ8oF/EVrsl/PvD7/6i+d8Et4eHChckQBVJ+lKt19HpHp7H+kPHCFU7+Fw7Zn5z3dLMwVfUA7Jr4MPhV/dfPhRRpVH1vXCl9iNOiMrPuIBhD2q1cN/I7OWtYfOK1yLT5I4frg3Ue6nvedRjVWg3ADl9754LVWl7pXSWQcsdvb97k7G7xaYerNlcYH/Ux/flAdH1RNJkRALseSs8qy5as4tDcAQIpP8u1vuViR7vr3sq5LuVrh+2DF8V5la9l+r65CwoA3ISs+uWa2OzCrLoCKffE9Zxy9bPf6adlMazkCkeWf3lcV62kWkcBoPq2BNsLoXSpMMznRDUIpDwcbHJ11/2gerOFllHsas3PF8VpdTPDXk673voPAELpamHUEi8CKY/I2V3XCSlvK/FL1dv5g4BbJnAAgMdDqYe2d+4ZhFGBlEfEBYFztbJpHa2+zfyaK5hrIX1cWBYnVyvptQstADweSuvXq8oSdeF+4TBO+oRASg+BZqp6s4fzvd/evJmo3ocvhhlD43tTtQNA47U4jJd8VeUfRlOiRf16YQIjgZRmuWZqvbI24w902+1Hrm61Li4A0C6UhnugZ9Vu9SwK9wm/GromkNIgdtfNtZal7ro/nowXGU/EB3GmZLqp96mHLQCw0vX4tgtveG3zNTR8ttAqeqgnlUBKO0cZt2183c8+Zdy2saSPe1/49gBgV4LprH6F1tLQg2mbAtt1/Ey/xvXQEUjpOcTMtCB1HtKPVO+jF79wYUjVZWau+w0AbHxtPqtuuvFuQzCdhs8SPpNWUYGUFfz25k3oqjvKtPlPavjBk2/OSXb2YxdsHva+sO0AwM7fF8UQ98/6P8OSKEN64HvbIvpM99zt91QVZKO7bj/C2NpcLdNhuxeq+MGL3rQO7KfVZg9hFnFiBgAg8XW6/mMaG0xex3uaUYFFDfcBn8ycK5CSLrxk+aJ6SrT0hDurT7ahfnJMQnQkkDY+DDjd4N+fq0IAyHqfFFpJw+skhtNwv/q8fo37DqHVzbCdhb0kkPZpkemGdN71B4ldO99n/NKyXFiTa7Slx3PJJ+qLLT6254Uf83Nf+8F+bxjOMXTu2MxeH/QTTm/vX8cxmP4r3kflWCniKh4/X6qbJQxdv/q9zhdxDnpi/wIAAPfFVtS9GFBH8X//Ui1/8B96qv155+8hhF6btBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAwXmiCgAAYPj+33/9n736j/17/3vxn//9fxdqx74ptdwCKQAAXdzYfu7rveub5xeJyxJuxv+Of5/3ESxiUBjXr+cxMIxblPmqfn2pX7NU5a3LMan/eL3kV07q97pK/NmXvuf9/X3n3717IFzduqr/3UnCfXNwZ9/sr7Bv5qnrq6Nyr31MPXV6BACgA+MtLctpvJkPN+Mf6tc0Zzit32ccw9hkxX86iq8QON7V2wlB4n0MEtcbFGnUUJ+X9evXxNUwWnMf7uc8DhPtm9tj6X08lq5zfxliuY9u33/TY6ou83SVjfyHcyMAACQJSSGc/lXfmF/G1qakoSG27H5eI/A8Fs4uY3mPM9bLfr39s23e8Rn2TTiW3sV9c5b6WHqk3Aepjql6m3/FVmyBFAAAejCJYWLjm/wQRmJX0xAaxhnKGsJOaN36o37tZ6qP04zb7jOIhn3zMfO+CQ85/khxLHVY7lEMpq2OKYEUAADyhImPq7QUPRAcws38H/XruIPy7sfgc5Zp+5dbFkZDff1VpWlZbBPwPsYHE0Mq9+0xNRFIAQCgH5frtG7Fm/jPMYx0KbRm5giPW9N1N+6b8KBgr+O3Pt6kO3iP5b5cdkyZ1AgAgC6cr/C7v1TLx+JNq++z3KY2r25mDW1yOxNpm5v7cEM+bztBTQwOq4bCq/j6e8OyBpO6DGG22sMMYXfW1yyyCcPoOvsmHFf/vvf//1GtPtHSJO7HVx2Uex7L/u9HjqmVyv3YMSWQAgCQXX0jerbCzfO4IZB+qLc3z1TULyuWNbR+nlbLl8j4Ok6zfh222N7+CsFhEYN+q5lyY1lfVu0m3skVSnPMuttVGD1YYd+0nsX4znIr4Tgatdj2QWhxbLtvVix3+F59WPGYOmoZTsMxdX1/eR1ddgEAYP2gHW7cQ8CatrgZ32sRTNqskRqCwmH9vs/CEhttW15jWUOIeRaDR5sAMUlcZYPsuluXedQy1IWHBK/CMdF234Tfib/7LD60uG65bw5alHt/xXK/WOOYCuu+voghvMnx/XILpAAAsHkwPWxxQ94U7sLMp03dakOQfLbqWo/3yrqIIeKkxa+/i2EspSHOuttm38zqVwiisw32zXSFcNdmPOllR+WexwczF6uWWyAFAIA0msbJPn/sB7Elctzw76exBes6RWHr7YTw0NTtc6/KM0PuYGbdjeu07rfYN69S7Js4xjaMEb1usW/eLSn3WZfljmU/WfWYEkgBACDNzfisIUTsPxIclgaLaJ5hPOdti1xTS+k4jutNaRBdd+O+OW34tVnqfRNasat2ExdNHmrBjuU+6rrcd46ppoczB7fHlEAKAADpLOtqOXosVFTLu1VeVyvOqrpigAgtpU3dNU/X3Px82TYH0HX3uMW+Ocy0X0LdTVv86tEa5V7kKncs+1nVPE756zFlll0AAOhXU0vWSaoulUuEcDJeEmK+tpKuMbtx2O6ytS9Ln3W3730TWq8/NPzOdcHH1F9Lfh6OqZFACgAAPYndFkdLfmWxyQRGbYVwUpclLFOyrCX0ddVudt67213U2w3dNx/rkvy16+4qS+10uG8OquWtjFe5900MjfMVyz1pKPd8kwmMVtz3oX4mywK/LrsAAJDO3oq//7Lh5+cdlr0pXB2ss9HYJXhZqCq1627Tvnlf6DH4vOHnHzosS+NYUoEUAAASiJPLLAtW8zVC3qyr8seJdJa9394GwbFpfc0SZ90dl7JvVrTsmLruosX93jG1dFy1QAoAAGk0jdu7uhdgQ2vqaFmA7WCc331fNgxpy4LJstay/bi8SkkPF0rbN23LvbS7bg/F+rTshwIpAABsHgRCUGsKVPe7Sja1Nn7p4aNcNfz8l3U33LLr7qiQXToqcN+00XRM/dlDmeYCKQAA5AujoYvkx6ab8jqQXa0YehZdf5YWs+huOtZzWdfd0LJXStfd8YbBvdRAOu+hTEuP46e/vXlz5jQCADAI09/fvl2ohiJC6CiGltdVu26sD3VXLS6QdhB4m2bdDUuBHMfW1JJd+xastM8fD6TV+ovcAgDQrfk2hpTChG6jqe+PZ2us39n3cTbOtfEQNus6frnkPcI+mMVxpwJpWsW17OqyCwAAeQPAoWr4yVC67j4Wqq+GWOklTsQkkAIAQL4w+qLEEFBAMFpUy2fdHZc06+59ha6b2qbce6WV6WnV7WK7AACsb6EKBuO8Dl1nAy37uKNQGrruhjG4j4W7krvu7g1034a6nhcVSH9/+/asAgAANhVaQmcxjLYJUU2/M9qBOgtdd/9YEvpC190XAulwNS3lo8suAAAkCFZ1CP1n/TpcoUWvuEAa11NdJunYyTgWs8Suu/OGn5faZbep3OMeyiSQAgBAS6F188ndV/3/nm16071muHvZw+dvClp/p37D2LV5WV2cNrWyZdD0sOB5ocdvU7n/1UOZxgIpAACsH5jCTX7TvCsrh6Y42dGyILbfwyQ0TUFrnul9l81E3Pmsu3GfLwt34xInCIrlvl43HGbyUiAFAIDNXFTNa0+uE5qaAt6kqw8YA/XBkl+5zrXcSaFdd5v2zUGhx+psWbiv67HrY2pZq/tCIAUAgObAFMLoScOvhdC0akj51PDzow4/ZlNQmWWu47OqrK67TfvmtNDDtancrzssS1MdzQRSAABoF5imVfO4z3erdOWstzmvlncNHXXRohXL3BR+33dQzcV03a33zazvfRP2S5hoquG1/0C5l3bbXePByTplDw8PmurnvUAKAADtNbWShpvwVbuWNgW9dx2MV7ysli9lMs/VXfdemGrsult128L3oed9865+fW54vS74mKoajilddgEAYIXANK+au66u2rV0Wi1viQvB4WOuzxRb+ZpazM47rOOzanlL9KjDXd40djjbvolL8Exa/Or7Nco9qjK2NtdlP6uaJ1D6ekwJpAAAsJqTFr/T+mY/jk9tCnyhm2XyABHDaJuWrHnHdXxYyAOIXvZNbL1sE3SnD617G8vd1Ep6kPGYahw7entMCaQAALBaSFm0DCkHK2xzWrWYcbfe5sdUXS3jrLVNgeS6j3DYoutul2W56HLfxNb10BV3r8W+OVlS7rOqecxzKPdlwmPqrOUx9a3cAikAAKwuhJRFw++sOk7vsGpeWiaE3D9id861A08IT9XN+MQm5w+1wHUUBNsEqq6ssm8ONtg3X7dRLV8q5dZJbAndtNyTEIATHFMhRLeZefjw7jElkAIAwOphqU1XzlG1wgRH8Sb9VYtfHcUA8XmVWV7DbKyxi+ZfVbs1NKexdbDvIFjC/l5l34SW0hBMJ20fSMTfDYEuPCjYa7lvpi3KfdWyDvfvHFMHax5TbQLtRZwF+JsnTicAAJQkttR8XvIrLzYZ01hv/3+X/Pg8tsy13dbnFjfiz1ZpZWw5rvO+UB9fqpvWsNtWxb0YNH6JZRytsL0QeA5blDXU1emSQPQkwfGw9D3avmfDvgrjZF9k3Ddhn/w77p/rO/viecsgt3JZNyz3dSz3n9VNT4DFncAdXv+Kx9bGx9RTpzwAAFjbeYtAEYJA6wARWr7qABH++q5q11pWxTKME32mVmG0Q6GV9nXV7ey6pe6b0Lp4uEG524bS8NkOqnYt6RsdU7rsAgDA+gFlXt0s27I0kKw6rjB2xwwhdtF1wC4sjN52jz4sqDx97ZvQ3fVVi3GjTeW+7rjcJ8uOKYEUAAA2DHEtbvJXneDodvzfry0CbwohXL1YpbtyD8H/oqDy3O6biw73zUmienxWNa+lm8LXOmoahyyQAgDAZjf5ITA0rfk4qlaY4OjOtq9j61Jo2ZpnKP7XyZnq93jWw1qj6wT/RUH7/TqGxKz7Joa6eeJyv6rytfJ+Xdalfo9fY3CvBFIAAMirzTIwp3GNyXVCxO1ENuGVonUrBIUQpp6V2ir6UJCqCuq6+8i+mabeN+t20W1Z7meJj6mwpMs/V5md2aRGAACU5naGz2U/38SybS/W2WAIDXXYDCHiqOFXJ/Vr7QAYW8rmsftvGJcaZmndr5rXrVzEwBBm4p23ablqaVHlaR189PPXn/08fu51AtM6P1t134TjYHxn34xblGsR982s63VfEx1Ta5f7/wswALVGe5K7KPJ/AAAAAElFTkSuQmCC" height="50" wdth="200"/>
				</div>
				<div class="section">
					<!-- DateTime details -->
					<div class="col s3">
						<table class="collapse">
							<tr>
								<th colspan="2">DateTime</th>
							</tr>
							<tr>
								<td>Date</td>
								<td>
									<xsl:value-of select="/Root/DateTimeStamp/Prop[@Name='Date']/Value"/>
								</td>
							</tr>
							<tr>
								<td>Time</td>
								<td>
									<xsl:value-of select="/Root/DateTimeStamp/Prop[@Name='Time']/Value"/>
								</td>
							</tr>
						</table>
						<div class="divider"/>
					</div>
					<!-- Error details -->
					<div class="col s3">
						<table class="collapse">
							<tr>
								<th colspan="2">
									<xsl:value-of select="/Root/Caller0/Step/Prop/@Name"/>
									<xsl:text> raise an error</xsl:text>
								</th>
							</tr>
							<tr>
								<td>Name</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/@Name"/>
								</td>
							</tr>
							<tr>
								<td>Type</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/@TypeName"/>
								</td>
							</tr>
							<tr>
								<td>Id</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop/Prop/Value"/>
								</td>
							</tr>
							<tr>
								<td>Pre Exp</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop/Prop[@Name='PreExpr']/Value"/>
								</td>
							</tr>
							<tr>
								<td>Post Exp</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop/Prop[@Name='PostExpr']/Value"/>
								</td>
							</tr>
							<tr>
								<td>Status Exp</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop/Prop[@Name='StatusExpr']/Value"/>
								</td>
							</tr>
							<tr>
								<td>Error Code</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop[@Name='Result']/Prop[@Name='Error']/Prop[@Name='Code']/Value"/>
								</td>
							</tr>
							<tr>
								<td>Error Message</td>
								<td>
									<xsl:value-of select="/Root/Caller0/Step/Prop/Prop[@Name='Result']/Prop[@Name='Error']/Prop[@Name='Msg']/Value"/>
								</td>
							</tr>
						</table>
						<div class="divider"/>
					</div>
					<!-- Error Context -->
					<div class="col s3">
						<table class="collapse">
							<tr>
								<th colspan="2">Error Context</th>
							</tr>
							<tr>
								<td>StackCallChain</td>
								<td>
									<xsl:value-of select="/Root/ErrorContext/Prop[@Name='CallStackChain']/Value"/>
								</td>
							</tr>
							<tr>
								<td>StepIndex</td>
								<td>
									<xsl:value-of select="/Root/ErrorContext/Prop[@Name='StepIndex']/Value"/>
								</td>
							</tr>
							<tr>
								<td>NumberOfStepsExecuted</td>
								<td>
									<xsl:value-of select="/Root/ErrorContext/Prop[@Name='NumStepsExecuted']/Value"/>
								</td>
							</tr>
							<tr>
								<td>CallStackDepth</td>
								<td>
									<xsl:value-of select="/Root/ErrorContext/Prop[@Name='CallStackDepth']/Value"/>
								</td>
							</tr>
						</table>
						<div class="divider"/>
					</div>
					<xsl:for-each select="/Root/*[starts-with(name(), 'Caller')]">
						<br />
						<details open="true">
							<summary>
								<i>
									<Strong>
										<xsl:value-of select="CallerSequenceFile"/> - ( <xsl:value-of select="CallerSequence"/> )
									</Strong>
								</i>

							</summary>
							<!-- Step Properties -->
							<div class="col s3">
								<ul class="tree">
									<xsl:apply-templates select="Step/Prop"/>
								</ul>
							</div>
							<!-- Locals -->
							<div class="col s3">
								<ul class="tree">
									<xsl:apply-templates select="Locals/Prop"/>
								</ul>
							</div>
							<!-- Parameters -->
							<div class="col s3">
								<ul class="tree">
									<xsl:apply-templates select="Parameters/Prop"/>
								</ul>
							</div>
							<!-- FileGlobals -->
							<div class="col s3">
								<ul class="tree">
									<xsl:apply-templates select="FileGlobals/Prop"/>
								</ul>
							</div>
							<!-- StationGlobals -->
							<div class="col s3">
								<ul class="tree">
									<xsl:apply-templates select="StationGlobals/Prop"/>
								</ul>
							</div>
						</details>
					</xsl:for-each>
					<!--  -->
				</div>
			</body>
		</html>
	</xsl:template>
	<!-- Template for  -->
	<xsl:template match="*[not(name() = 'EnumValue' or name() = 'Value')]">
		<li>
			<details open="true">
				<summary>
					<xsl:choose>
						<xsl:when test="@Name">
							<strong>
								<xsl:value-of select="@*[name() = 'Name']"/>
							</strong>
						</xsl:when>
						<xsl:otherwise>
							<strong>
								<xsl:value-of select="name()"/>
							</strong>
						</xsl:otherwise>
					</xsl:choose>
					<xsl:text> ( </xsl:text>
					<xsl:value-of select="@Type"/>
					<xsl:text> ) </xsl:text>
				</summary>
				<xsl:if test="@*">
					<ul>
						<xsl:for-each select="@*">
							<xsl:if test="name() != 'IsAlias' and name() != 'Flags' and name() != 'Name' and name() != 'Type'">
								<li class="attr">
									<xsl:value-of select="name()"/>: <span class="value">
										<xsl:value-of select="."/>
									</span>
								</li>
							</xsl:if>
						</xsl:for-each>
					</ul>
				</xsl:if>
				<xsl:if test="node() or text()">
					<ul>
						<xsl:apply-templates/>
					</ul>
				</xsl:if>
			</details>
		</li>
	</xsl:template>
	<xsl:template match="*[count(*) = 1 and Value and not(Value/*)]">
		<li>
			<xsl:choose>
				<xsl:when test="@Name">
					<strong>
						<xsl:value-of select="@*[name() = 'Name']"/>
					</strong>
				</xsl:when>
				<xsl:otherwise>
					<strong>
						<xsl:value-of select="name()"/>
					</strong>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text> ( </xsl:text>
			<xsl:value-of select="@Type"/>
			<xsl:text> ) </xsl:text>
			<xsl:text> : </xsl:text>
			<span class="value">
				<xsl:value-of select="."/>
			</span>
		</li>
	</xsl:template>
	<xsl:template match="*[@Type='Array' and @ElementType='Obj']">
		<li>
			<details open="true">
				<summary>
					<xsl:choose>
						<xsl:when test="@Name">
							<strong>
								<xsl:value-of select="@*[name() = 'Name']"/>
							</strong>
						</xsl:when>
						<xsl:otherwise>
							<strong>
								<xsl:value-of select="name()"/>
							</strong>
						</xsl:otherwise>
					</xsl:choose>
					<xsl:text> ( </xsl:text>
					<xsl:value-of select="@Type"/>
					<xsl:text> of </xsl:text>
					<xsl:value-of select="@ElementType"/>
					<xsl:text>[</xsl:text>
					<xsl:value-of select="translate(@LBound, '[]', '')"/>
					<xsl:text>...</xsl:text>
					<xsl:value-of select="translate(@HBound, '[]', '')"/>
					<xsl:text>] )</xsl:text>
				</summary>
				<xsl:if test="@*">
					<ul>
						<xsl:for-each select="@*">
							<xsl:if test="name() != 'Flags' and name() != 'Name' and name() != 'Type' and name() != 'ElementType' and name() != 'LBound' and name() != 'HBound'">
								<li class="attr">
									<xsl:value-of select="name()"/>: <span class="value">
										<xsl:value-of select="."/>
									</span>
								</li>
							</xsl:if>
						</xsl:for-each>
					</ul>
				</xsl:if>
				<xsl:if test="node()">
					<ul>
						<xsl:apply-templates/>
					</ul>
				</xsl:if>
			</details>
		</li>
	</xsl:template>
	<xsl:template match="*[@Type='Array' and @ElementType != 'Obj']">
		<li>
			<details open="true">
				<summary>
					<xsl:choose>
						<xsl:when test="@Name">
							<strong>
								<xsl:value-of select="@*[name() = 'Name']"/>
							</strong>
						</xsl:when>
						<xsl:otherwise>
							<strong>
								<xsl:value-of select="name()"/>
							</strong>
						</xsl:otherwise>
					</xsl:choose>
					<xsl:text> ( </xsl:text>
					<xsl:value-of select="@Type"/>
					<xsl:text> of </xsl:text>
					<xsl:value-of select="@ElementType"/>
					<xsl:text>[</xsl:text>
					<xsl:value-of select="translate(@LBound, '[]', '')"/>
					<xsl:text>...</xsl:text>
					<xsl:value-of select="translate(@HBound, '[]', '')"/>
					<xsl:text>] )</xsl:text>
				</summary>
				<xsl:if test="@*">
					<ul>
						<xsl:for-each select="*">
							<li>
								<xsl:value-of select="@ID"/>
								<xsl:text> : </xsl:text>
								<span class="value">
									<xsl:value-of select="."/>
								</span>
							</li>
						</xsl:for-each>
					</ul>
				</xsl:if>
				<xsl:if test="node()">
					<ul>
						<xsl:apply-templates/>
					</ul>
				</xsl:if>
			</details>
		</li>
	</xsl:template>
	<xsl:template match="*[parent::Value[@ID]]">
		<li>
			<xsl:value-of select="../@ID"/>
			<xsl:text> : </xsl:text>
			<xsl:choose>
				<xsl:when test="@Name">
					<strong>
						<xsl:value-of select="@*[name() = 'Name']"/>
					</strong>
				</xsl:when>
				<xsl:otherwise>
					<strong>
						<xsl:value-of select="name()"/>
					</strong>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text> ( </xsl:text>
			<xsl:value-of select="@Type"/>
			<xsl:text> ) </xsl:text>
			<xsl:if test="@*">
				<ul>
					<xsl:for-each select="@*">
						<xsl:if test="name() != 'Flags' and name() != 'Name' and name() != 'Type'">
							<li class="attr">
								<xsl:value-of select="name()"/>: <span class="value">
									<xsl:value-of select="."/>
								</span>
							</li>
						</xsl:if>
					</xsl:for-each>
				</ul>
			</xsl:if>
			<xsl:if test="node() or text()">
				<ul>
					<xsl:apply-templates/>
				</ul>
			</xsl:if>
		</li>
	</xsl:template>
	<xsl:template match="*[@Type='Enumeration']">
		<li>
			<xsl:choose>
				<xsl:when test="@Name">
					<strong>
						<xsl:value-of select="@*[name() = 'Name']"/>
					</strong>
				</xsl:when>
				<xsl:otherwise>
					<strong>
						<xsl:value-of select="name()"/>
					</strong>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text> ( </xsl:text>
			<xsl:value-of select="@Type"/>
			<xsl:text> ) (</xsl:text>
			<span style="color: green;">
				<xsl:value-of select="@TypeName"/>
			</span>
			<xsl:text> ) : #</xsl:text>
			<span style="color: blue;">
				<xsl:value-of select="Value"/>
			</span>
			<xsl:text># "</xsl:text>
			<span style="color: red;">
				<xsl:value-of select="EnumValue"/>
			</span>
			<xsl:text>" </xsl:text>
		</li>
	</xsl:template>
	<xsl:template match="*[child::* and @TypeName and not(@Type='Enumeration')]">
		<li>
			<details open="true">
				<summary>
					<xsl:choose>
						<xsl:when test="@Name">
							<strong>
								<xsl:value-of select="@*[name() = 'Name']"/>
							</strong>
						</xsl:when>
						<xsl:otherwise>
							<strong>
								<xsl:value-of select="name()"/>
							</strong>
						</xsl:otherwise>
					</xsl:choose>
					<xsl:text> (</xsl:text>
					<xsl:value-of select="@Type"/>
					<xsl:text> ) (</xsl:text>
					<span style="color: green;">
						<xsl:value-of select="@TypeName"/>
					</span>
					<xsl:text> )</xsl:text>
					<xsl:text> : </xsl:text>
					<xsl:if test="count(*) = 1 and Value and not(Value/*)">
						<span class="value">
							<xsl:value-of select="."/>
						</span>
					</xsl:if>
				</summary>
				<xsl:if test="@*">
					<ul>
						<xsl:for-each select="@*">
							<xsl:if test="name() != 'IsAlias' and name() != 'Class' and name() != 'Flags' and name() != 'Name' and name() != 'Type' and name() != 'TypeName'">
								<li class="attr">
									<xsl:value-of select="name()"/>: <span class="value">
										<xsl:value-of select="."/>
									</span>
								</li>
							</xsl:if>
						</xsl:for-each>
					</ul>
				</xsl:if>
				<xsl:if test="node() or text()">
					<ul>
						<xsl:apply-templates/>
					</ul>
				</xsl:if>
			</details>
		</li>
	</xsl:template>
	<xsl:template match="*[not(child::*) and @TypeName and not(@Type='Enumeration')]">
		<li>
			<xsl:choose>
				<xsl:when test="@Name">
					<strong>
						<xsl:value-of select="@*[name() = 'Name']"/>
					</strong>
				</xsl:when>
				<xsl:otherwise>
					<strong>
						<xsl:value-of select="name()"/>
					</strong>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text> ( </xsl:text>
			<xsl:value-of select="@Type"/>
			<xsl:text> ) (</xsl:text>
			<span style="color: green;">
				<xsl:value-of select="@TypeName"/>
			</span>
			<xsl:text> )</xsl:text>
			<xsl:text> : </xsl:text>
			<xsl:if test="count(*) = 1 and Value and not(Value/*)">
				<span class="value">
					<xsl:value-of select="."/>
				</span>
			</xsl:if>
			<xsl:if test="@*">
				<ul>
					<xsl:for-each select="@*">
						<xsl:if test="name() != 'IsAlias' and name() != 'Class' and name() != 'Flags' and name() != 'Name' and name() != 'Type' and name() != 'TypeName'">
							<li class="attr">
								<xsl:value-of select="name()"/>: <span class="value">
									<xsl:value-of select="."/>
								</span>
							</li>
						</xsl:if>
					</xsl:for-each>
				</ul>
			</xsl:if>
			<xsl:if test="node() or text()">
				<ul>
					<xsl:apply-templates/>
				</ul>
			</xsl:if>
		</li>
	</xsl:template>
	<xsl:template match="text()">
		<!-- Do nothing, effectively ignoring the text nodes -->
	</xsl:template>
</xsl:stylesheet>
