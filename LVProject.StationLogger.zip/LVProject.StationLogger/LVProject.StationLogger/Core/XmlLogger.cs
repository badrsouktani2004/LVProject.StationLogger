﻿using LVProject.StationLogger.DataStructures;
using LVProject.StationLogger.Services;
using LVProject.StationLogger.Utils;
using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml;

namespace LVProject.StationLogger.Core
{
    public static class XmlLogger
    {
        /// <summary>
        /// Équivalent du VI Global.
        /// Orchestre la création simultanée d'un rapport XML/HTML et d'un journal CSV.
        /// </summary>
        public static ErrorCluster Execute(
            object sequenceContextIn,
            string logPath,
            string stepName,
            string stepTypeName,
            ErrorCluster errorIn)
        {

            try
            {

                string dllPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string dllDirectory = Path.GetDirectoryName(dllPath)!;

                string styleSheetPath = Path.Combine(dllDirectory, "Resources", "StyleSheet.xsl");
                string xmlStyleSheet = File.ReadAllText(styleSheetPath);

                DateTime now = DateTime.Now;

               
                string dateStr = now.ToString("ddMMyyyy");       // %d%m%Y
                string timeStr = now.ToString("HHmmssfff");      // %H%M%S%3u (fff = millisecondes)


                double errorCodeNum = GetPropertyNumberValue(sequenceContextIn, "RunState.Caller.Step.Result.Error.Code");

                string errorCodeStr = errorCodeNum.ToString(CultureInfo.InvariantCulture);

                string uniqueFileName = $"{dateStr}_{timeStr}_{errorCodeStr}";

                string sequenceErrorsFolder = Path.Combine(logPath, "SequenceErrors");
                string basePath = Path.Combine(sequenceErrorsFolder, uniqueFileName);

                string xmlFilePath = basePath + ".xml";
                string htmlFilePath = basePath + ".html";


                ErrorCluster xmlFlowError = errorIn;
                string innerXmlContent = string.Empty;

                var createXmlDocResult = CreateXmlDocument.Execute(xmlFilePath,xmlFlowError);
                XmlDocument? xmlDoc = createXmlDocResult.DocRef;
                XmlNode? rootNode = createXmlDocResult.RootNode;
                xmlFlowError = createXmlDocResult.ErrorOut;
                string fileNamePath = createXmlDocResult.FileNamePath;


                var dateTimeResult = GetCurrentDateAndTime.Execute(xmlFlowError);
                xmlFlowError = dateTimeResult.ErrorOut;


                xmlFlowError = AddNodeWithStringValue.Execute(xmlDoc, rootNode, dateTimeResult.TagName, dateTimeResult.DateTimeString, xmlFlowError);

                xmlFlowError = ErrorContextDetailsBuildUp.Execute(sequenceContextIn, xmlDoc, rootNode, xmlFlowError);

                xmlFlowError = AddDataToXmlDoc.Execute(sequenceContextIn, xmlDoc, rootNode, xmlFlowError);

                if (!xmlFlowError.Status && xmlDoc != null)
                {
                    
                    xmlDoc.Save(fileNamePath);

                    innerXmlContent = xmlDoc.InnerXml;
                }


                ErrorCluster htmlFlowError = xmlFlowError;
                htmlFlowError = XmlToHtmlTransformer.Execute(xmlStyleSheet, innerXmlContent, htmlFilePath, htmlFlowError);
                

                ErrorCluster csvFlowError = AppendLogInSequenceErrors.Execute(
                    logPath,
                    now,
                    stepName,
                    stepTypeName,
                    errorCodeStr,
                    uniqueFileName, 
                    errorIn);       

                return MergeErrors(htmlFlowError, csvFlowError);
            }
            catch (Exception ex)
            {
                string sourceMsg = $"Erreur fatale dans le logger global : {ex.Message}";
                Logger.WriteError("XmlLogger", sourceMsg, ex);

                return new ErrorCluster
                {
                    Status = true,
                    Code = -1,
                    Source = sourceMsg
                };
            }
        }



        /// <summary>
        /// Équivalent du sous-VI "TestStand - Get Property Value (Number).vi".
        /// </summary>
        private static double GetPropertyNumberValue(object sequenceContext, string lookupString)
        {
            dynamic? propertyObject = null;

            try
            {
                dynamic context = sequenceContext;
                propertyObject = context.AsPropertyObject();

                return propertyObject.GetValNumber(lookupString, 0);
            }
            catch
            {
                
                return 0.0;
            }
            finally
            {
                if (propertyObject != null && Marshal.IsComObject(propertyObject))
                {
                    Marshal.ReleaseComObject(propertyObject);
                }
            }
        }

        /// <summary>
        /// Équivalent du bloc LabVIEW "Merge Errors".
        /// Retourne la première erreur trouvée, en priorisant le flux supérieur.
        /// </summary>
        private static ErrorCluster MergeErrors(ErrorCluster error1, ErrorCluster error2)
        {
            if (error1.Status) return error1;
            if (error2.Status) return error2;

            return new ErrorCluster { Status = false, Code = 0, Source = "" };
        }
    }
}