﻿namespace LVProject.StationLogger.DataStructures
{

    public class GetCurrentDateAndTimeResult
    {
        public string Date { get; set; } = string.Empty;
        public string Time { get; set; } = string.Empty;
        public string TagName { get; set; } = string.Empty;
        public string DateTimeString { get; set; } = string.Empty;
        public ErrorCluster ErrorOut { get; set; }
    }
}