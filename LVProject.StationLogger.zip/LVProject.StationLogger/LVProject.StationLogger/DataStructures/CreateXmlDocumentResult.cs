﻿using System.Xml;

namespace LVProject.StationLogger.DataStructures
{
    public class CreateXmlDocumentResult
    {
        public XmlDocument? DocRef { get; set; }
        public XmlNode? RootNode { get; set; }
        public string FileNamePath { get; set; } = string.Empty;

        public ErrorCluster ErrorOut { get; set; }
    }
}