﻿namespace LVProject.StationLogger.DataStructures
{
    public struct ErrorCluster
    {
        public bool Status { get; set; }
        public int Code { get; set; }
        public string Source { get; set; }

 
        public static ErrorCluster NoError => new()
        {
            Status = false,
            Code = 0,
            Source = string.Empty
        };
    }
}