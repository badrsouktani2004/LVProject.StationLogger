﻿using System;
using System.IO;

namespace LVProject.StationLogger.Utils
{
    public static class Logger
    {

        private static readonly string LogFilePath = @"C:\Temp\StationLogger_DebugLog.txt";

        /// <summary>
        /// Écrit un message d'erreur formaté dans un fichier texte silencieusement.
        /// </summary>
        /// <param name="module">Le nom du sous-VI ou du service (ex: "NewXmlDocumentStrInit")</param>
        /// <param name="message">Le message descriptif du problème</param>
        /// <param name="ex">L'exception C# capturée (optionnel)</param>
        public static void WriteError(string module, string message, Exception? ex = null)
        {
            try
            {
                string? directory = Path.GetDirectoryName(LogFilePath);

                // On s'assure que le chemin du dossier n'est pas vide avant de tenter de le créer
                if (!string.IsNullOrWhiteSpace(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                string timeStamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string logLine = $"[{timeStamp}] [{module}] {message}";

                if (ex != null)
                {
                    logLine += $" | Détails techniques : {ex.Message}";
                }

                File.AppendAllText(LogFilePath, logLine + Environment.NewLine);
            }
            catch
            {
                // Bloc de sécurité absolu : si l'écriture du fichier échoue (ex: disque plein),
                // on capture l'erreur ici en silence pour ne JAMAIS faire crasher TestStand.
            }
        }
    }
}